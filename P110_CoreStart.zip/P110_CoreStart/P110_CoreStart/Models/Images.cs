﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P110_CoreStart.Models
{
    public static class Images
    {
        private static List<ImageItem> images = new List<ImageItem>
        {
            new ImageItem{ Id = 1, Link = "slider1.jpg", Title = "Cloud"},
            new ImageItem{ Id = 2, Link = "slider2.jpg", Title = "Up"},
            new ImageItem{ Id = 3, Link = "slider3.jpg", Title = "Sumgayit"},
            new ImageItem{ Id = 4, Link = "slider4.jpg", Title = "Qazax"},
            new ImageItem{ Id = 5, Link = "slider5.jpg", Title = "Qusar"}
        };

        private static string[] users = new string[]
        {
            "Samir",
            "Medis",
            "Shems",
            "Kamuran",
            "Aqil",
            "Elcin",
            "Kamil"
        };

        public static List<ImageItem> GetAllImages() => images;
        public static string[] GetAllUsers() => users;
    }

    public class ImageItem
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Link { get; set; }
    }
}
