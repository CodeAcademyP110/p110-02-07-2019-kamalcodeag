﻿var nameItems = document.querySelectorAll(".name-item");

for (var item of nameItems) {
    item.onclick = function () {
        this.remove();
    }
}