﻿using P110_CoreStart.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P110_CoreStart.ViewModels
{
    public class UsersAndImagesVM
    {
        public string[] Users { get; set; }
        public IEnumerable<ImageItem> Images { get; set; }
    }
}
