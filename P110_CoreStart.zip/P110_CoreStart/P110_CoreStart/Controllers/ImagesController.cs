﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P110_CoreStart.Models;

namespace P110_CoreStart.Controllers
{
    public class ImagesController : Controller
    {
        public IActionResult Index()
        {
            return View(Images.GetAllImages());
        }

        public IActionResult Details(int id)
        {
            ImageItem selectedImage = Images.GetAllImages().FirstOrDefault(i => i.Id == id);

            if(selectedImage == null)
            {
                return NotFound();
            }

            return File("~/img/"+selectedImage.Link, "image/jpg");
        }
    }
}