﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using P110_CoreStart.Models;
using P110_CoreStart.ViewModels;

namespace P110_CoreStart
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            #region Json
            //List<Person> people = new List<Person>
            //{
            //    new Person{Id = 1, Firstname = "Medine", Lastname = "Eliyeva"},
            //    new Person{Id = 2, Firstname = "Elmar", Lastname = "Ibrahimli"},
            //    new Person{Id = 3, Firstname = "Kamran", Lastname = "Orucov"}
            //};

            //return Json(new {
            //    students = people,
            //    id = 2,
            //    name = "samir",
            //    surname = "dadash"
            //});

            //public class Person
            //{
            //    public int Id { get; set; }
            //    public string Firstname { get; set; }
            //    public string Lastname { get; set; }
            //}

        #endregion

            //ViewBag.ImagesList = Images.GetAllImages();

            UsersAndImagesVM viewModel = new UsersAndImagesVM
            {
                Users = Images.GetAllUsers(),
                Images = Images.GetAllImages().OrderBy(i => i.Id).Take(3)
            };

            return View(viewModel);
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        public IActionResult Error()
        {
            return View();
        }

    }
    
}
